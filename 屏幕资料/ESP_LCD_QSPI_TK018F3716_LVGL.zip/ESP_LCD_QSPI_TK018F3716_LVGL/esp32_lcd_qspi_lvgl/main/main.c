#include <stdio.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/i2c.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lvgl_port.h"
#include "esp_timer.h"
#include "freertos/semphr.h"
#include "esp_heap_caps.h"
#include "esp_lcd_panel_io_interface.h"
#include "esp_lcd_io_spi.h"

#include "esp_lcd_touch_ft5x06.h"
#include "esp_lcd_tk018.h"

#include "lv_demos.h"

#include "ui.h"
#include "myui.h"

static const char *TAG = "main";

#define TOUCH_ENABLE  1     //触摸开关

#define test_lvgl 1         //lvgl案例开关

#define QSPI_ENABLE  1      //QSPI模式开关

// 240x240屏 触摸I2C地址 0x15
#define TEST_LCD_HOST               SPI2_HOST
#define TEST_LCD_H_RES              (240)
#define TEST_LCD_V_RES              (300)
#define TEST_LCD_BIT_PER_PIXEL      (16)

#define TEST_PIN_NUM_LCD_CS         (GPIO_NUM_16)
#define TEST_PIN_NUM_LCD_PCLK       (GPIO_NUM_6)
#define TEST_PIN_NUM_LCD_DATA0      (GPIO_NUM_15)
#define TEST_PIN_NUM_LCD_DATA1      (GPIO_NUM_7)
#define TEST_PIN_NUM_LCD_DATA2      (GPIO_NUM_17)
#define TEST_PIN_NUM_LCD_DATA3      (GPIO_NUM_18)
#define TEST_PIN_NUM_LCD_RST        (GPIO_NUM_NC)
#define TEST_PIN_NUM_BK_LIGHT       (GPIO_NUM_0)   
#define TEST_LCD_BK_LIGHT_ON_LEVEL  (1)
#define TEST_LCD_BK_LIGHT_OFF_LEVEL !TEST_LCD_BK_LIGHT_ON_LEVEL


/* Touch settings */
#define EXAMPLE_TOUCH_I2C_NUM       (1)
#define EXAMPLE_TOUCH_I2C_CLK_HZ    (400000)
/* LCD touch pins */
#define EXAMPLE_TOUCH_I2C_SCL       (GPIO_NUM_5)
#define EXAMPLE_TOUCH_I2C_SDA       (GPIO_NUM_4)
#define EXAMPLE_TOUCH_GPIO_INT      (GPIO_NUM_NC)

/* LCD IO and panel */
static esp_lcd_panel_io_handle_t lcd_io = NULL;
static esp_lcd_panel_handle_t lcd_panel = NULL;

/* LVGL display and touch */
static lv_display_t *lvgl_disp = NULL;
static lv_indev_t *lvgl_touch_indev = NULL;

/* LCD Touch IO and panel */
static esp_lcd_panel_io_handle_t tp_io_handle = NULL;
static esp_lcd_touch_handle_t touch_handle = NULL;

#define TEST_DELAY_TIME_MS          (3000)
 
static SemaphoreHandle_t refresh_finish = NULL;

/**
 * @brief 全屏填充指定颜色
 *        参照 test_draw_bitmap 使用 SPI_SWAP_DATA_TX 处理字节序
 *        分段传输, 每次发送的行数能整除垂直分辨率
 * @param panel_handle LCD面板句柄
 * @param rgb565_color RGB565颜色值 (如 0x001F=蓝, 0xF800=红, 0x07E0=绿, 0xFFFF=白)
 */
static void test_draw_color_screen(esp_lcd_panel_handle_t panel_handle, uint16_t rgb565_color)
{
    refresh_finish = xSemaphoreCreateBinary();

    uint16_t row_line = TEST_LCD_V_RES / TEST_LCD_BIT_PER_PIXEL;  // 300/16=18行/段, 与test_draw_bitmap一致
    uint8_t byte_per_pixel = TEST_LCD_BIT_PER_PIXEL / 8;
    uint8_t *color = (uint8_t *)heap_caps_calloc(1, row_line * TEST_LCD_H_RES * byte_per_pixel, MALLOC_CAP_DMA);

    /* 使用SPI_SWAP_DATA_TX预交换字节序, 与test_draw_bitmap完全一致 */
    uint16_t color_swapped = SPI_SWAP_DATA_TX(rgb565_color, TEST_LCD_BIT_PER_PIXEL);
    for (int i = 0; i < row_line * TEST_LCD_H_RES; i++) {
        for (int k = 0; k < byte_per_pixel; k++) {
            color[i * byte_per_pixel + k] = (color_swapped >> (k * 8)) & 0xff;
        }
    }

    /* 分段发送, 覆盖全屏 */
    for (int j = 0; j < TEST_LCD_BIT_PER_PIXEL; j++) {
        esp_lcd_panel_draw_bitmap(panel_handle, 0, j * row_line, TEST_LCD_H_RES, (j + 1) * row_line, color);
        xSemaphoreTake(refresh_finish, portMAX_DELAY);
    }

    free(color);
    vSemaphoreDelete(refresh_finish);
}

IRAM_ATTR static bool test_notify_refresh_ready(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_io_event_data_t *edata, void *user_ctx)
{
    BaseType_t need_yield = pdFALSE;

    xSemaphoreGiveFromISR(refresh_finish, &need_yield);
    return (need_yield == pdTRUE);
}

static void test_draw_bitmap(esp_lcd_panel_handle_t panel_handle)
{
    refresh_finish = xSemaphoreCreateBinary();
    //TEST_ASSERT_NOT_NULL(refresh_finish);

    uint16_t row_line = TEST_LCD_V_RES / TEST_LCD_BIT_PER_PIXEL;
    uint8_t byte_per_pixel = TEST_LCD_BIT_PER_PIXEL / 8;
    uint8_t *color = (uint8_t *)heap_caps_calloc(1, row_line * TEST_LCD_H_RES * byte_per_pixel, MALLOC_CAP_DMA);
    //TEST_ASSERT_NOT_NULL(color);

    for (int j = 0; j < TEST_LCD_BIT_PER_PIXEL; j++) {
        for (int i = 0; i < row_line * TEST_LCD_H_RES; i++) {
            for (int k = 0; k < byte_per_pixel; k++) {
                color[i * byte_per_pixel + k] = (SPI_SWAP_DATA_TX(BIT(j), TEST_LCD_BIT_PER_PIXEL) >> (k * 8)) & 0xff;
            }
        }
        esp_lcd_panel_draw_bitmap(panel_handle, 0, j * row_line, TEST_LCD_H_RES, (j + 1) * row_line, color);
        xSemaphoreTake(refresh_finish, portMAX_DELAY);
    }
    free(color);
    vSemaphoreDelete(refresh_finish);
    //vTaskDelay(pdMS_TO_TICKS(3000));
}


static void test_draw_bitmap2(esp_lcd_panel_handle_t panel_handle)
{
    refresh_finish = xSemaphoreCreateBinary();

    uint16_t row_line = TEST_LCD_V_RES / TEST_LCD_BIT_PER_PIXEL;
    uint8_t byte_per_pixel = TEST_LCD_BIT_PER_PIXEL / 8;
    uint8_t *color = (uint8_t *)heap_caps_calloc(1, row_line * TEST_LCD_H_RES * byte_per_pixel, MALLOC_CAP_DMA);

    for (int j = 0; j < TEST_LCD_BIT_PER_PIXEL; j++) {
        for (int i = 0; i < row_line * TEST_LCD_H_RES; i++) {
            uint16_t color_val = BIT(j);
            
            // 根据颜色格式处理
            if (TEST_LCD_BIT_PER_PIXEL == 16) {
                // 16位565格式：交换R和B分量
                uint16_t r = (color_val >> 11) & 0x1F;    // 取5位R
                uint16_t g = (color_val >> 5) & 0x3F;     // 取6位G
                uint16_t b = color_val & 0x1F;            // 取5位B
                
                // 交换R和B
                color_val = (b << 11) | (g << 5) | r;
                
                // 存储（小端格式）
                color[i * 2] = color_val & 0xFF;
                color[i * 2 + 1] = (color_val >> 8) & 0xFF;
            }
            else if (TEST_LCD_BIT_PER_PIXEL == 24 || TEST_LCD_BIT_PER_PIXEL == 32) {
                // 24/32位格式：RGB转BGR
                uint8_t r = (color_val >> 16) & 0xFF;
                uint8_t g = (color_val >> 8) & 0xFF;
                uint8_t b = color_val & 0xFF;
                
                color[i * byte_per_pixel] = b;      // B
                color[i * byte_per_pixel + 1] = g;  // G
                color[i * byte_per_pixel + 2] = r;  // R
                
                // 32位可能有Alpha通道
                if (byte_per_pixel == 4) {
                    color[i * 4 + 3] = 0xFF;  // Alpha固定为不透明
                }
            }
        }
        esp_lcd_panel_draw_bitmap(panel_handle, 0, j * row_line, TEST_LCD_H_RES, (j + 1) * row_line, color);
        xSemaphoreTake(refresh_finish, portMAX_DELAY);
    }
    free(color);
    vSemaphoreDelete(refresh_finish);
    //vTaskDelay(pdMS_TO_TICKS(3000));
}



static esp_err_t lcd_init(void)
{
    
#if QSPI_ENABLE

    ESP_LOGI(TAG, "Initialize QSPI bus");
    const spi_bus_config_t buscfg = SPD2010_PANEL_BUS_QSPI_CONFIG(TEST_PIN_NUM_LCD_PCLK,
                                                                  TEST_PIN_NUM_LCD_DATA0,
                                                                  TEST_PIN_NUM_LCD_DATA1,
                                                                  TEST_PIN_NUM_LCD_DATA2,
                                                                  TEST_PIN_NUM_LCD_DATA3,
                                                                  TEST_LCD_H_RES * TEST_LCD_V_RES * TEST_LCD_BIT_PER_PIXEL / 8);

    const esp_lcd_panel_io_spi_config_t io_config = SPD2010_PANEL_IO_QSPI_CONFIG(TEST_PIN_NUM_LCD_CS, NULL, NULL);

#else

    ESP_LOGI(TAG, "Initialize SPI bus");
    const spi_bus_config_t buscfg = SPD2010_PANEL_BUS_SPI_CONFIG(TEST_PIN_NUM_LCD_PCLK,
                                                                 TEST_PIN_NUM_LCD_DATA0,
                                                                 TEST_LCD_H_RES * TEST_LCD_V_RES * TEST_LCD_BIT_PER_PIXEL / 8);

    const esp_lcd_panel_io_spi_config_t io_config = SPD2010_PANEL_IO_SPI_CONFIG(
        TEST_PIN_NUM_LCD_CS, 
        TEST_PIN_NUM_LCD_DATA1, 
        test_notify_refresh_ready, 
        NULL);                                                             

#endif                                                                 
    
    
    ESP_RETURN_ON_ERROR(spi_bus_initialize(TEST_LCD_HOST, &buscfg, SPI_DMA_CH_AUTO), TAG, "LCD spi_bus_initialize failed");

    ESP_LOGI(TAG, "Install panel IO");

    // Attach the LCD to the SPI bus
    ESP_RETURN_ON_ERROR(esp_lcd_new_panel_io_spi(TEST_LCD_HOST, &io_config, &lcd_io), TAG, "LCD esp_lcd_new_panel_io_spi failed");

    ESP_LOGI(TAG, "Install SPD2010 panel driver");

    const spd2010_vendor_config_t vendor_config = {
        .flags = {
            .use_qspi_interface = QSPI_ENABLE,
        },
    };
    const esp_lcd_panel_dev_config_t panel_config = {
        .reset_gpio_num = TEST_PIN_NUM_LCD_RST,
        .rgb_ele_order = LCD_RGB_ELEMENT_ORDER_BGR,
        .bits_per_pixel = TEST_LCD_BIT_PER_PIXEL,
        .vendor_config = (void *) &vendor_config,
    };
    ESP_RETURN_ON_ERROR(esp_lcd_new_panel_tk018(lcd_io, &panel_config, &lcd_panel), TAG, "LCD esp_lcd_new_panel_tk018 failed");
    esp_lcd_panel_reset(lcd_panel);
    esp_lcd_panel_init(lcd_panel);
    esp_lcd_panel_disp_on_off(lcd_panel, true);

    return ESP_OK;
}

static esp_err_t lcd_deinit(void)
{
    ESP_RETURN_ON_ERROR(esp_lcd_panel_del(lcd_panel), TAG, "LCD panel deinit failed");
    ESP_RETURN_ON_ERROR(esp_lcd_panel_io_del(lcd_io), TAG, "LCD IO deinit failed");
    // ESP_RETURN_ON_ERROR(spi_bus_free(EXAMPLE_LCD_SPI_NUM), TAG, "SPI BUS free failed");
    // ESP_RETURN_ON_ERROR(gpio_reset_pin(EXAMPLE_LCD_GPIO_BL), TAG, "Reset BL pin failed");
    return ESP_OK;
}

static esp_err_t app_touch_init(void)
{
    /* Initilize I2C */
    const i2c_config_t i2c_conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = EXAMPLE_TOUCH_I2C_SDA,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_io_num = EXAMPLE_TOUCH_I2C_SCL,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = EXAMPLE_TOUCH_I2C_CLK_HZ
    };
    ESP_RETURN_ON_ERROR(i2c_param_config(EXAMPLE_TOUCH_I2C_NUM, &i2c_conf), TAG, "I2C configuration failed");
    ESP_RETURN_ON_ERROR(i2c_driver_install(EXAMPLE_TOUCH_I2C_NUM, i2c_conf.mode, 0, 0, 0), TAG, "I2C initialization failed");

    /* Initialize touch HW */
    const esp_lcd_touch_config_t tp_cfg = {
        .x_max = TEST_LCD_H_RES,
        .y_max = TEST_LCD_V_RES,
        .rst_gpio_num = GPIO_NUM_NC, // Shared with LCD reset
        .int_gpio_num = GPIO_NUM_NC,
        .levels = {
            .reset = 0,
            .interrupt = 0,
        },
        .flags = {
            .swap_xy = 0,
            .mirror_x = 0,
            .mirror_y = 1,
        },
    };
    const esp_lcd_panel_io_i2c_config_t tp_io_config = ESP_LCD_TOUCH_IO_I2C_FT5x06_CONFIG();
    ESP_RETURN_ON_ERROR(esp_lcd_new_panel_io_i2c((esp_lcd_i2c_bus_handle_t)EXAMPLE_TOUCH_I2C_NUM, &tp_io_config, &tp_io_handle), TAG, "");
    return esp_lcd_touch_new_i2c_ft5x06(tp_io_handle, &tp_cfg, &touch_handle);
}

static esp_err_t lvgl_init(void)
{
    /* Initialize LVGL */
    const lvgl_port_cfg_t lvgl_cfg = {
        .task_priority = 4,         /* LVGL task priority */
        .task_stack = 16384,         /* LVGL task stack size */
        .task_affinity = -1,        /* LVGL task pinned to core (-1 is no affinity) */
        .task_max_sleep_ms = 500,   /* Maximum sleep in LVGL task */
        .timer_period_ms = 5        /* LVGL timer tick period in ms */
    };
    ESP_RETURN_ON_ERROR(lvgl_port_init(&lvgl_cfg), TAG, "LVGL port initialization failed");

    /* Add LCD screen */
    ESP_LOGD(TAG, "Add LCD screen");
    const lvgl_port_display_cfg_t disp_cfg = {
        .io_handle = lcd_io,
        .panel_handle = lcd_panel,
        .buffer_size = TEST_LCD_H_RES * TEST_LCD_V_RES,
        .double_buffer = 0,
        // .buffer_size = TEST_LCD_H_RES * 80 * TEST_LCD_BIT_PER_PIXEL / 8,
        // .double_buffer = 0,
        .trans_size = 0,
        .hres = TEST_LCD_H_RES,
        .vres = TEST_LCD_V_RES,
        .monochrome = 0,                                    //是否使用单色
        .color_format = LV_COLOR_FORMAT_RGB565,

        .rotation = {
            .swap_xy = 0,
            .mirror_x = 0,
            .mirror_y = 1,
        },
        .flags = {
            .buff_dma = 1,      //使用dma
            .buff_spiram = 0,   //使用spiram
            .sw_rotate = 0,     //旋转角度
            .swap_bytes = 1,    //交换字节
            .full_refresh = 1,  //全屏刷新
            .direct_mode = 0,   //直接模式
        }
    };

    lvgl_disp = lvgl_port_add_disp(&disp_cfg);
    if (lvgl_disp == NULL) {
        ESP_LOGE(TAG, "Failed to add display");
        return ESP_FAIL;
    }

#if TOUCH_ENABLE
    /* Add touch input (for selected screen) */
    const lvgl_port_touch_cfg_t touch_cfg = {
        .disp = lvgl_disp,
        .handle = touch_handle,
    };
    lvgl_touch_indev = lvgl_port_add_touch(&touch_cfg);
#endif

    return ESP_OK;
}

static void app_main_display(void)
{
    /* Task lock */
    lvgl_port_lock(0);

    /* LVGL demo */
    lv_demo_widgets();
    // lv_demo_stress();

    // ui_init();
    // my_ui_init();


    /* Task unlock */
    lvgl_port_unlock();
}



void app_main(void)
{

#if TOUCH_ENABLE
    /* TOUCH initialization */
    ESP_ERROR_CHECK(app_touch_init());
#endif
    /* LCD HW initialization */
    ESP_ERROR_CHECK(lcd_init());


#if test_lvgl

    /* LVGL initialization */
    lvgl_init();
    app_main_display();

#else

    int n = 0;
    while(1)
    {

        if(n%2)
        {
            test_draw_color_screen(lcd_panel, 0xFFE0); //黄色
            vTaskDelay(pdMS_TO_TICKS(2000));//等待2秒
            test_draw_bitmap(lcd_panel);
            vTaskDelay(pdMS_TO_TICKS(2000));//等待2秒
        }
           
        else
        {
            test_draw_color_screen(lcd_panel, 0xF800); //红色
            vTaskDelay(pdMS_TO_TICKS(2000));//等待2秒
            test_draw_bitmap2(lcd_panel);
            vTaskDelay(pdMS_TO_TICKS(2000));//等待2秒
        }

        n++;
        vTaskDelay(pdMS_TO_TICKS(100));
        
    }
    

     
#endif


    while(1) vTaskDelay(pdMS_TO_TICKS(2000));//等待2秒
}
