#include "stm32f10x.h"

#define XSIZE_PHYS 240
#define YSIZE_PHYS 284

#define SPI_CS(a)	\
						if (a)	\
						GPIO_SetBits(GPIOA,GPIO_Pin_4);	\
						else		\
						GPIO_ResetBits(GPIOA,GPIO_Pin_4)

#define LCD_RS(a)	\
						if (a)	\
						GPIO_SetBits(GPIOA,GPIO_Pin_6);	\
						else		\
						GPIO_ResetBits(GPIOA,GPIO_Pin_6)

#define Lcd_Light_ON   GPIOA->BSRR = GPIO_Pin_2;
#define Lcd_Light_OFF  GPIOA->BRR  = GPIO_Pin_2;

//*************  24λɫ��1600��ɫ������ *************//
//#define WHITE          0xFFFFFF
//#define BLACK          0x000000
//#define BLUE           0x0000FF
//#define BLUE2          0x3F3FFF
//#define RED            0xFF0000
//#define MAGENTA        0xFF00FF
//#define GREEN          0x00FF00
//#define CYAN           0x00FFFF
//#define YELLOW         0xFFFF00

//*************  18λɫ��26��ɫ������ *************//
//#define White          0x3FFFF
//#define Black          0x00000
//#define Blue           0x3F000
//#define Blue2          0x3F3CF
//#define Red            0x0003F
//#define Magenta        0x3F03F
//#define Green          0x0FFC0
//#define Cyan           0x3FFC0
//#define Yellow         0x0FFFF						

////*************  16λɫ���� *************//
#define WHITE						0xFFFF
#define BLACK						0x0000	  
#define BLUE						0x001F  
#define BRED						0XF81F
#define GRED						0XFFE0
#define GBLUE						0X07FF
#define RED							0xF800
#define MAGENTA					0xF81F
#define GREEN						0x07E0
#define CYAN						0x7FFF
#define YELLOW					0xFFE0
#define BROWN						0XBC40 //��ɫ
#define BRRED						0XFC07 //�غ�ɫ
#define GRAY						0X8430 //��ɫ

//Lcd��ʼ������ͼ����ƺ���
void LCD_delay(int time);
void Lcd_Initialize(void);
//Lcd�߼����ƺ���
void Lcd_ColorBox(u16 x,u16 y,u16 xLong,u16 yLong,u32 Color);
void DrawPixel(u16 x, u16 y, u32 Color);
void draw_Bat(u16 x,u16 y,u8 power_per);
void LCD_Fill_Pic(u16 x, u16 y,u16 pic_H, u16 pic_V, const unsigned char* pic);
void BlockWrite(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend);
void LCD_PutString(unsigned short x, unsigned short y, char *s, unsigned int fColor, unsigned int bColor,unsigned char flag);
