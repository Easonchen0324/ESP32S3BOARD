
#ifndef  __TOUCH_CTP_H__
#define  __TOUCH_CTP_H__
#include "stm32f10x.h"
#include "stdio.h"



#define I2C1_SCL(x) 	\
						if (x)	\
						GPIOA->BSRR = GPIO_Pin_2;	\
						else		\
						GPIOA->BRR  = GPIO_Pin_2;
						
#define I2C1_SDA(x)	\
						if (x)	\
						GPIOA->BSRR = GPIO_Pin_3;	\
						else		\
						GPIOA->BRR  = GPIO_Pin_3;

#define	I2C1_SDA_Read()  	  	SDA_read_Bit()   
						
#define CTP_ADDR				0x2A		//��ַΪ0x38Ҫ��һλ 
						
						
void Touch_GPIO_Config(void); 
int SDA_read_Bit(void);
void I2C1_Start(void);
void I2C1_Stop(void);
void I2C1_Ack(void);
void I2C1_NoAck(void);

void I2C1_Send_Byte(uint8_t dat);
uint8_t I2C1_Read_Byte(uint8_t ack);
uint8_t I2C1_WaitAck(void);


static uint8_t CTP_Write_Reg(uint8_t startaddr,uint8_t *pbuf,uint32_t len);
uint8_t CTP_Read_Reg(uint8_t *pbuf,uint32_t len);

int GUI_TOUCH_X_MeasureX(void); 
int GUI_TOUCH_X_MeasureY(void);

void Touch_Test(void);

#endif                                     

