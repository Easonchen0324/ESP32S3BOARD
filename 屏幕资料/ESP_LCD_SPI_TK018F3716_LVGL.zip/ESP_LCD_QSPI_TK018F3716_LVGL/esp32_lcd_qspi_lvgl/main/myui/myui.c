﻿#include "myui.h"
#include "ui.h"
#include <stdio.h>
//#include "gif1.c"

static const char *TAG = "myui";

//gif显示
void gif_show()
{
	LV_IMG_DECLARE(gif2);
	lv_obj_t* img1 = lv_gif_create(ui_Container5);
	lv_gif_set_src(img1, &gif2);
	lv_obj_align(img1, LV_ALIGN_CENTER, 0, 0);
	
	
	LV_IMG_DECLARE(gif5);
	lv_obj_t* img2 = lv_gif_create(ui_Container6);
	lv_gif_set_src(img2, &gif5);
	lv_obj_align(img2, LV_ALIGN_CENTER, 0, 0);
}
#include "esp_log.h"
//设置温度
void set_temp()
{
	static int temp_value=0;
	static char str[24]={0};
	
	temp_value = temp_value>=100? 0:temp_value+5;
	
	sprintf(str, "%d", temp_value);
	lv_label_set_text(ui_temp_label, str);
	lv_bar_set_value(ui_Bar1, temp_value, LV_ANIM_ON);

}

//设置湿度
void set_humi()
{
	static int humi_value=0;
	static char str[24]={0};
	
	humi_value = humi_value>=100? 0:humi_value+2;
	
	sprintf(str, "%d", humi_value);
	lv_label_set_text(ui_humi_label, str);
	lv_bar_set_value(ui_Bar2, humi_value, LV_ANIM_ON);
}
	
static const lv_img_dsc_t * ui_imgset_tq[7] = {&ui_img_tq1_png, &ui_img_tq2_png, &ui_img_tq3_png, &ui_img_tq4_png, &ui_img_tq5_png, &ui_img_tq6_png, &ui_img_tq7_png}; //图片数组
static lv_obj_t *weather_img[7];
//天气    图片预加载
void weather_img_show()
{
	int i=0;
	
	for(i=0;i<7;i++)
	{
		weather_img[i] = lv_img_create(ui_weather_container1);
		lv_img_set_src(weather_img[i], ui_imgset_tq[i]);
		lv_obj_set_width(weather_img[i], LV_SIZE_CONTENT);   /// 50
		lv_obj_set_height(weather_img[i], LV_SIZE_CONTENT);    /// 50
		lv_obj_set_x(weather_img[i], 0);
		lv_obj_set_y(weather_img[i], -16);
		lv_obj_set_align(weather_img[i], LV_ALIGN_CENTER);
		lv_obj_add_flag(weather_img[i], LV_OBJ_FLAG_ADV_HITTEST || LV_OBJ_FLAG_HIDDEN);     /// Flags		
		
	}

	lv_obj_clear_flag(ui_Image10, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
}

//天气显示
void weather_show()
{
	static int i=0;
	static char *weather_buff[7] = {"晴", "多云", "阴", "阵雨", "雨", "雪", "雾"};

	if(i==0)
	{
		lv_obj_clear_flag(weather_img[i], LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(weather_img[6], LV_OBJ_FLAG_HIDDEN);
	}
	else
	{
		lv_obj_clear_flag(weather_img[i], LV_OBJ_FLAG_HIDDEN);
		lv_obj_add_flag(weather_img[i-1], LV_OBJ_FLAG_HIDDEN);
	}

	lv_label_set_text(ui_weather_label1, weather_buff[i]);
	i = i>=6 ? 0:i+1;
	
}

//初始化
void my_ui_init()
{

	gif_show();	//gif显示
	
	lv_timer_t *temp_up = lv_timer_create(set_temp, 500, NULL);	//设置温度
	
	lv_timer_t *humi_up = lv_timer_create(set_humi, 500, NULL);	//设置湿度
	
	weather_img_show();	//天气图片预加载
	lv_timer_t *weather_up = lv_timer_create(weather_show, 1000, NULL);	//设置湿度

}
