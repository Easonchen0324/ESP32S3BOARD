#ifndef MYUI_H
#define MYUI_H

void my_ui_init();

#endif
