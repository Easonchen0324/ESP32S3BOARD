#ifndef __QSPI_FUN_H__
#define __QSPI_FUN_H__
#include "HAL_device.h"
#include "QSPI_REG.h"
#include "sys.h" 

void QSPI_FunCnofig(void);
void QSPI_FunLine(u8 mode);
void QSPI_FunSendbyte(u8 data);
void QSPI_FunSendGroup(u8* pData,u32 len);
void QSPI_FunNSS(u8 cs);
void QSPI_FunDmaRxConfig(u32 adress,u32 len);
void QSPI_FunDmaTxConfig(u32 adress,u32 len);
void QSPI_FunRW(u8 rw);
void QFLASH_FunReadGroup(u32 add,u8 *pBuf,u32 len);
void QFLASH_FunWriteCmd(u8 cmd);
void QFLASH_FunCheckStatus(void);
void QFLASH_FunErase(u32 add,u8 eType);
void QFLASH_FunEraseAll(void);
int  get_file_address_NOR_FLASH(char *s);
void QFLASH_FunReadGroup_Quad_REG(u32 add,u8 *pBuf,u32 len);
void QFLASH_FunReadGroup_Quad_DMA(u32 add,u8 *pBuf,u32 len);
void QFLASH_FunReadGroup_long_address(u32 add,u8 *pBuf,u32 len);
void QSPI_PageProgram_Quad_REG(u32 add,u8*pBuf,uint32_t len);
void QFLASH_FunProgram_Quad_DMA(u32 add,u8*pBuf,u32 len);
void QFLASH_FunProgram(u32 add,u8*pBuf,u32 len);
void QFLASH_FunProgram_long_address(u32 add,u8*pBuf,u32 len);
void QFLASH_FunErase_long_address(u32 add,u8 eType);//eType 0:SE_Com (Erase 4KB), 1:BE64K_Com
#endif

